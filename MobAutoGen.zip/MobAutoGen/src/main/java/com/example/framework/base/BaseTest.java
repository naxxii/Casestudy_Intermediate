package com.example.framework.base;

import com.example.framework.utils.ConfigReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.net.MalformedURLException;
import java.net.URL;

public class BaseTest {
    protected AppiumDriver<MobileElement> driver;
    protected ConfigReader config;

    @BeforeMethod
    public void setUp() throws MalformedURLException {
        config = new ConfigReader("src/main/resources/config.properties");

        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability("platformName", config.getProperty("platformName"));
        caps.setCapability("deviceName", config.getProperty("deviceName"));
        caps.setCapability("appPackage", config.getProperty("appPackage"));
        caps.setCapability("appActivity", config.getProperty("appActivity"));
        caps.setCapability("automationName", config.getProperty("automationName"));
        caps.setCapability("autoGrantPermissions", true);

        driver = new AndroidDriver<>(
                new URL(config.getProperty("appiumServerURL")),
                caps
        );
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
