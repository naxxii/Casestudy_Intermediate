package com.example.framework.pages;


import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

    private final AppiumDriver<MobileElement> driver;

    @AndroidFindBy(id = "com.example.myapp:id/username")
    private MobileElement usernameField;

    @AndroidFindBy(id = "com.example.myapp:id/password")
    private MobileElement passwordField;

    @AndroidFindBy(id = "com.example.myapp:id/loginButton")
    private MobileElement loginButton;

    public LoginPage(AppiumDriver<MobileElement> driver) {
        this.driver = driver;
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public void enterUsername(String username) {
        usernameField.clear();
        usernameField.sendKeys(username);
    }

    public void enterPassword(String password) {
        passwordField.clear();
        passwordField.sendKeys(password);
    }

    public void tapLogin() {
        loginButton.click();
    }
}